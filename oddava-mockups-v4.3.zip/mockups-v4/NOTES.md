# oddava.me mockups v4: composition B, iterated

Static, self-contained mockups of the home and about pages. These are not
production pages, and nothing in the site's `src/` was changed. v3
(`../mockups-v3/`) is untouched.

- `index.html` links both pages and these notes.
- `home.html` and `about.html` are each built into one file: fonts, CSS and JS
  are inlined, and they work offline from `file://`.
- `src/` holds the sources. Run `node build.mjs` to rebuild the pages,
  `node qa.mjs <dir>` to write the QA probe variants, and `node contrast.mjs`
  for the contrast table.
- `COPY-SOURCES.md` records where every word came from: main commit
  `8f84eca42ed9237ef98d9e644970ae0bc21ad1ff`.
- `SOURCES.md` covers the vereis.com study and the other references.
- `TEST-RESULTS.md` has the probe output and the contrast table.

## v4.3 (owner-approved small iteration on v4.2)

1. **Home has no header or nav.** The duplicate wordmark and the
   about/projects/notes links are gone, with nothing replacing them.
2. **notes is the last project** on home, linking to `https://notes.oddava.me`
   with the same styling as the others. Its description is the first sentence
   of the notes site, verbatim: "a collection of things i want to remember,
   revisit or build upon." Sources are in COPY-SOURCES.md. This is now the only
   notes.oddava.me link in the mock.
3. **The home h1 `oddava` links to About** (`about.html` here, `/about` in
   production). It has the same accent underline as the project names, and its
   wording is unchanged. The tilde stays under it.
4. **About has no nav.** It keeps only a small `oddava` wordmark at the top,
   linking home (`home.html` here, `/` in production). There is no notes link
   on About.
5. **Unchanged:** the appearance control, the tilde, the kaomoji, the palette,
   the type, and all copy apart from the new notes line.
6. **CSS:** the unused `.nav` rules are removed. The wavy current-page nav
   underline went with the nav.

Screenshots: `screenshots/*-v43.png`, plus `qa/reflow-320-*-v43.png`. The v4.2
captures are kept unsuffixed.

## What changed from v3 B

1. **The logo is plain.** The dd tie is gone. The wordmark is just `oddava` in
   DM Sans 600 at 19px, with normal glyphs and kerning, no ligature, bar or
   mascot.
2. **Copy is the site's own, word for word.**
   - From main `8f84eca`, cross-checked against the live pages: the lowercase
     tagline, the three About paragraphs, and the About title and meta.
   - From the live public https://oddava.me/projects, as published on
     2026-11-11: the four projects (Oddava's minesweeper, Ishbay, oddava.me,
     AniShows).
   - The checked-in `DEFAULT_PROJECTS` fallback is no longer used. It isn't
     what the public site shows, and it included an "oddava notes" entry the
     live site doesn't list.

   There is no real name anywhere. Invented bio lines from older mocks are gone.
   The home notes section is omitted. In v4.2 the only notes link was "notes" in the nav,
   to notes.oddava.me.
3. **Light and dark themes,** plus a system setting that follows the OS.
4. **The six appearance preferences are back,** in an unobtrusive "appearance"
   control in the footer.
5. **Small personal touches** suited to someone who lists games and anime as
   interests (see below).

## Appearance preferences

Saved as JSON in `localStorage.appearance`. Applied before first paint by an
inline script that checks each value against an allow-list, then set as
attributes on `<html>`:

| attribute      | values                                    | default       | effect                                                                                       |
| -------------- | ----------------------------------------- | ------------- | -------------------------------------------------------------------------------------------- |
| `data-theme`   | system, light, dark                       | system        | Token set. System follows `prefers-color-scheme`.                                            |
| `data-ink`     | ai, sakura, matcha, fuji, sora            | ai (#245DCC)  | Accent and focus ring, each with its own light and dark value (contrast in TEST-RESULTS). No cream, coral or yellow. |
| `data-read`    | sans, serif                               | sans          | Prose only (`.prose`: tagline, project blurbs, about body). Serif is Lora. UI and headings stay DM Sans. |
| `data-size`    | standard, large                           | standard      | Root size 100% or 112.5%; every size is in rem, so all of it scales.                         |
| `data-density` | comfortable, compact                      | comfortable   | Vertical rhythm × 0.68 and line height 1.6 → 1.5.                                            |
| `data-motion`  | system, reduced                           | system        | Reduced turns off the panel animation and the press settle. The OS reduced-motion setting always wins. |

The control:

- **Toggle:** a native `<button>` with `aria-expanded` and `aria-controls`. Its
  dot shows the current ink.
- **Panel:** `role=group`, labelled by its heading. Each preference is a native
  radio `<fieldset>` with a `<legend>`, styled as segments with a visible focus
  ring. Changes apply instantly; there is no save button.
- **Closing:**
  - Escape closes the panel and returns focus to the toggle.
  - An outside pointerdown closes it and returns focus only if focus was inside.
  - Tabbing out of the panel closes it.
- **Placement:**
  - It opens upward when there is room above the toggle, otherwise downward
    (the short About page).
  - At ≤30em it becomes a fixed sheet along the bottom of the screen.
  - Its max height comes from `innerHeight`.
- **Reset** removes the key and restores the defaults.
- **Storage messages:** if storage is blocked, a `role=status` line says the
  settings won't persist. The controls still work for the visit.
- **Motion:** 170ms scale-and-fade in and 110ms out (WAAPI). It is cancelled if
  the panel is reopened mid-animation and skipped when motion is reduced.
- **Scope:** there are no notes-site settings.

## Personality: small, on purpose

The brief asked for cute and anime touches, without a mascot, cat, stars,
emoji bullets or a busy metaphor. Each touch is small, decorative only, and
hidden from assistive tech where it is a glyph:

- **A tilde under the name:** a 44px hand-drawn wave in the visitor's ink. It
  borrows the "~" voice from vereis.com, as a line rather than a character.
- **Wavy underlines:**
  - In v4.2 the current nav page got a wavy underline. v4.3 removed the nav,
    and the underline with it.
  - Text links turn wavy and take the ink colour on hover.
  - The resting underline stays straight, so links still read as links.
- **Kaomoji:**
  - `( ˘ω˘ )` sits quietly in the appearance panel header.
  - `(◕‿◕)` sits beside **AniShows**, the anime tracker, in the ink colour.
    It is visible at rest on every device, touch included, and is completely
    still: no hover state, transition or transform. It always takes the same
    space, so the link's hit area and layout don't change. The link's hover
    and focus states are unchanged.

  These are the only two, and nothing else on the page uses one.
- **Ink names:** ai, sakura, matcha, fuji, sora (indigo, cherry blossom, green
  tea, wisteria, sky). They are named like that rather than "blue/pink/green".
  Screen readers get both, for example "sakura (pink)".

Rejected:

- a character illustration (vereis's move, and it would read as copied);
- sparkles or stars;
- a loading cat;
- anime data such as a "currently watching" list: there is no such source data,
  and inventing it is not allowed.

## Second subtractive critique (on the final renders)

| Problem seen                                                                                | Fix                                                                                       |
| -------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| Panel captured mid-fade, looked translucent                                                  | Probe finishes animations before capture. The real open state is fully opaque.            |
| Ink choices wrapped onto three lines                                                         | Panel widened to 27rem, legend column 6rem                                                |
| Panel opened above the top of the page on the short About page, so it was unreachable        | Opens downward (`.below`) when there isn't room above                                     |
| `100dvh` rejected by the renderer, and the page min-height flex was unnecessary             | Removed. The panel max-height is set from `innerHeight` in JS.                            |
| Mobile: about 120px of dead space between the last project and the footer                   | Footer gap is 44px × density below 55em and stays 72px on desktop                         |
| Dark panel: swatches showed light-theme inks while the toggle dot showed the dark one       | Swatches use each ink's value for the current theme                                       |
| `( ˘ᵕ˘ )` rendered with a missing or tiny glyph in the system font                          | Replaced with `( ˘ω˘ )` (Greek ω is in every system font)                                 |
| Final pass: at rest, the home read as a neutral directory; the one anime-flavoured detail only appeared on hover or focus, so touch visitors never saw it | The AniShows kaomoji is visible at rest in the ink colour, completely still, with the same footprint. No new glyphs or copy. |
| About desktop: "for businesses." wraps alone at 1440                                        | Kept. `text-wrap: pretty` is avoiding a one-word "businesses." orphan; the copy is fixed. |

## Hard-ban check

| Ban                                                        | Status                                                                                              |
| ---------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| Cream or terracotta                                        | Pass. White/ink light theme, cool charcoal dark theme. Inks contain no cream, coral or yellow.      |
| Inter or Instrument Serif                                  | Pass. DM Sans throughout, with Lora only behind the serif preference.                               |
| Purple gradients, glass, card grids                        | Pass. No gradients or backdrop blur. Projects are a list, not cards.                                |
| Emoji bullets, stars, cat, mascot                          | Pass. Two aria-hidden kaomoji (explicitly permitted), no emoji.                                     |
| All-caps or mono microlabels, `§`, dotted leaders          | Pass. Lowercase labels in the UI face; no uppercase transforms or monospace.                        |
| An arrow on every link                                     | Pass. No arrows anywhere.                                                                           |
| Scroll choreography, loaders                               | Pass. No scroll-linked motion. Motion is the panel open/close and the 1px press settle.   |
| `transition: all`                                          | Pass. Every transition names its properties.                                                        |
| More than one notes link per page                          | Pass. v4.3 has one on home (the last project) and none on About.                                    |
| Real name                                                  | Pass. "oddava" only.                                                                                |

## Screenshots

All captures are **full-page at auto height**: the frame grows to fit the
document. They are not cropped to a device viewport, so a 390 capture is
"390 wide, whole page", not a 390 × 844 phone screen.

Core (`screenshots/`):

| file                    | size        |
| ----------------------- | ----------- |
| `home-1440-light.png`   | 1440 × 672  |
| `home-1440-dark.png`    | 1440 × 672  |
| `home-390-light.png`    | 390 × 874   |
| `home-390-dark.png`     | 390 × 874   |
| `about-1440-light.png`  | 1440 × 556  |
| `about-1440-dark.png`   | 1440 × 556  |
| `about-390-light.png`   | 390 × 616   |
| `about-390-dark.png`    | 390 × 616   |

Settings open (`screenshots/`):

| file                            | size        | note                                                   |
| ------------------------------- | ----------- | ------------------------------------------------------ |
| `settings-open-1440-light.png`  | 1440 × 672  | opens upward from the footer toggle                    |
| `settings-open-1440-dark.png`   | 1440 × 672  |                                                        |
| `settings-open-390-light.png`   | 390 × 874   | fixed sheet. Position is relative to the auto-height frame, not a phone screen |
| `settings-open-390-dark.png`    | 390 × 874   | same                                                   |

QA (`screenshots/qa/`):

- `reflow-320-home-light.png`;
- `combo-home-1440-light-fuji-serif-large-compact-reduced.png`;
- `combo-about-390-dark-matcha-serif-large.png`;
- `denied-storage-about-1440-open-below.png`: the panel opening downward, with
  the storage status shown;
- `anishows-kaomoji-focus-1440-dark.png` and
  `anishows-kaomoji-focus-320-light.png`: the AniShows entry keyboard-focused.
  The kaomoji at rest is in every home capture.

`reference/vereis-reference.png` is the vereis.com study render (see
SOURCES.md).

## Limitations

- **Projects:** the list is a point-in-time copy of the live, admin-published
  list from https://oddava.me/projects, fetched read-only on 2026-11-11 at
  19:29 Tashkent time. A snapshot is in `reference/`. The owner can change it
  in `/admin` at any time. Admin and Redis were not accessed. Years, cover
  images and secondary links are not shown. See COPY-SOURCES.md.
- **Out of scope, omitted rather than faked:**
  - the guestbook (needs Redis, auth and signing);
  - now-playing;
  - the home carousel controls;
  - the cats.
- **Testing gaps:** there was no real Tab traversal or pointer automation (the
  preview tool's key and click input didn't work), no OS reduced-motion
  emulation and no screen-reader pass. See TEST-RESULTS.md.
- **The CSP / inline-script story is not production-shaped.** The mock inlines
  its scripts and has a few `style="--sl…"` attributes on swatches.
  Production's hashed CSP would want these as classes.
- **Not owner-approved.** This is a review iteration.
