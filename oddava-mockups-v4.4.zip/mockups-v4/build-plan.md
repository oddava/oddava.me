# v4 build plan (planning only, nothing applied)

This plan is docs only. No branch, worktree, commit, admin write or Redis
access was made to write it. It comes from a read-only inspection of the repo
guides (`CLAUDE.md`, `AGENTS.md`, `docs/notes-api.md`) and narrow
`git show 8f84eca:<path>` reads.

**STOP POINT:** nothing below starts until the owner approves this plan,
including the open decisions at the end.

## 0. Base commit (owner decision first)

- Local `main` is at `fce296a`. That is **24 commits behind** `8f84eca`
  (`origin/main`, already present locally). Those 24 commits include:
  - the notes cutover to notes.oddava.me;
  - the projects tray, image focus and zoom;
  - the admin revamp.
- The mock's copy was checked against `8f84eca`. Branching `redesign/v4` from
  today's local main would rebuild on superseded code.
- **Recommendation:** with approval, fast-forward local `main` to `8f84eca`.
  Then create the worktree and branch:
  `git worktree add -b redesign/v4 <new-path> main`.
  - The fast-forward needs no fetch because the object is already local.
  - Do not base on `redesign/rubric` or PR36.
  - Do not touch the main checkout's uncommitted `NoteShelves.astro`: no stash,
    reset or clean.
  - **Not run now.**

## 1. Boundary: a scoped portfolio shell, not a global restyle

Inspected shared consumers at `8f84eca` (`git grep`):

| File | Consumers besides home, about and projects | Plan |
| --- | --- | --- |
| `src/layouts/Base.astro` | `components/garden/NotesShell.astro` (notes pages), `pages/404·500·503.astro`, `pages/links.astro` | **Unchanged** |
| `src/components/SiteNav.astro`, `styles/components/_site-nav.css` | Base (so notes); `_site-nav.css` is also imported by `layouts/NotesLayout.astro` and `_note-search.css` | **Unchanged** |
| `src/components/Footer.astro`, `QuietSky.astro` | Base; QuietSky is also used by `layouts/AdminLayout.astro` | **Unchanged** |
| `src/components/SiteHead.astro` → `DocumentTheme.astro` | NotesShell, NotesLayout, Immersive; `DocumentTheme` is also used by AdminLayout | One opt-out prop only (below) |
| `src/styles/global.css` (`_fonts`, `_variables`, `_layout`…) | Base, NotesLayout, Immersive; `_variables`, `_fonts` and `_layout` are shared with `admin.css` and AdminLayout | **Unchanged** |
| `components/projects/ProjectCard.astro`, `home/ProjectStrip.astro`, `lib/project-gallery.ts`, `styles/components/_home.css` | home and projects only | Replaced; deleted only once grep shows no consumer |
| `styles/components/_projects.css` | home, projects, and `tests/project-image.test.ts` (asserts the `.pcard__img[data-x/y/zoom]` rules) | Keep the focus and zoom rules, or move them and update that test in the same commit |

**New, portfolio-only files.** Only `pages/index.astro`, `about.astro` and
`projects/index.astro` move to them.

- **`src/layouts/Portfolio.astro`:**
  - `<html data-site="portfolio">`;
  - imports `styles/portfolio/portfolio.css` instead of `global.css`;
  - renders `SiteHead` with `documentTheme={false}`;
  - adds the portfolio prepaint, header and footer.
- **`src/components/portfolio/`:**
  - `Header.astro`: wordmark, then projects/about/notes. The notes href is
    `notesIndexUrl()`, so it keeps working on both hosts. The current page gets
    `aria-current="page"`, and the appearance icon sits at the end.
  - `Footer.astro`: the off-site contacts from `data/links.json`, plus `/rss.xml`.
  - `AppearanceControl.astro`: the panel with native radios.
  - `Prepaint.astro`.
  - `ProjectList.astro` (home) and `ProjectShot.astro` (projects).
- **`src/styles/portfolio/*.css`:** tokens, reset and components, every
  selector under `[data-site='portfolio']`. Astro bundles CSS per route, and
  this scope is a second guard, so notes, Studio and admin can't change.
- **`src/scripts/appearance.ts`:** a bundled module served from `'self'`; no
  inline JS beyond the prepaint.
- **The single shared edit:** `SiteHead.astro` gets an optional
  `documentTheme?: boolean`, defaulting to `true`. Every existing caller
  renders byte-identical output, and a test pins that.
- **Fonts:** DM Sans and Lora are not in the repo (`_fonts.css` holds
  JetBrains Mono and M PLUS Rounded 1c). Add self-hosted latin woff2 subsets
  under `public/fonts/` with their OFL texts. No npm dependency is needed, and
  `font-src 'self'` already allows them.
- **Out of scope:**
  - links, 404, 500 and 503 keep Base;
  - the notes host, Studio, admin and every `src/lib/server/**` file are not
    touched.

## 2. Milestones (each one is a commit, and `pnpm run verify` must stay green)

1. **M0 baseline.**
   - Run `pnpm run verify` on the base.
   - Capture baseline screenshots of `/`, `/projects`, `/about`, one notes
     page, `/admin/login` and Studio. Notes, admin and Studio must stay
     pixel-equal throughout.
2. **M1 shell.**
   - Portfolio layout, tokens, fonts, header and footer, the `SiteHead` prop.
   - Prepaint and appearance control.
3. **M2 projects.**
   - One centred column of `ProjectShot` cards from `readPublicProjects()`.
   - The `503` rewrite on storage loss is kept, and `project-gallery.ts` is
     dropped.
4. **M3 home.**
   - The prerendered page keeps the server-island project block, now a text
     list from `pickHomeProjects()` (featured first, limit
     `HOME_PROJECT_LIMIT = 3`), then a `see all` link to `/projects`.
   - The awake band, the cat and RecentNotes leave home; notes appear only in
     the nav.
5. **M4 about.** Prose, title and meta stay byte-identical; the guestbook
   depends on the open decision below.
6. **M5 cleanup and QA.** Delete the orphaned home and projects components and
   CSS after a grep confirms they're unused, then do the full browser pass.

## 3. Data, screenshots and Studio/admin compatibility

- **No schema change.** `Project` in `lib/contracts.ts` already has `year`,
  `image {src, alt, fit, x, y, zoom}`, `featured` and `hidden`.
- **Storage stays as it is:**
  - `projects:list` (one hash, Lua compare-and-set on `revision`, 409 on a
    stale tab);
  - images in the media store under `/images/notes/…`, served by
    `pages/images/notes/[...path].ts`.
- `ProjectsPanel` and the admin API stay unchanged.
- **Cards reuse `displayAttributes()`** from `lib/project-image.ts` for
  focus, zoom and `contain`. This works through data attributes, not inline
  styles, so it stays CSP-safe.
- **No image means a labelled `preview unavailable` slot**, the current
  `pcard--blank` case. AniShows needs no data change.
- **Admin writes are gated.** None happen during planning or implementation
  without a separate explicit owner OK. Each would go through `/admin`, one
  revision-checked save at a time:
  1. Set `hidden: true` on the oddava.me entry. This is not a delete; it stays
     in the admin list.
  2. Optionally upload a redacted Ishbay cover as **new** media and repoint
     `image.src`. The old object stays; no delete or migration.
  3. Optionally set `featured` to pin the home three.

## 4. Six preferences, kept CSP-safe

- **Storage:** `localStorage.appearance` is JSON with `theme`, `ink`, `read`,
  `size`, `density` and `motion`.
- **Prepaint:**
  - `Prepaint.astro` holds a fixed inline IIFE in `<head>`, before the
    stylesheet. It whitelists values, sets `data-*` on `<html>`, and falls back
    to the defaults on missing, bogus or denied storage.
  - The exact bytes are registered with `Astro.csp?.insertScriptHash()`. This
    mirrors how `DocumentTheme.astro` registers its style hash today.
  - No `unsafe-inline` or `unsafe-eval`, and no `style=""`.
    `scripts/verify-build-output.mjs` already fails on both.
- **Swatches** from the mock's `style="--sl…"` become per-ink classes.
- **The canvas pre-style** is a hashed inline `<style>` (`color-scheme: light
  dark`) plus two `theme-color` metas with `media`.
- **Hash coverage:** `/projects` is SSR, so add a test that its response
  carries the same script hash as the prerendered `/` and `/about`.

## 5. Contracts that must not move

- the `/api/notes*` Bearer auth and `409` revision/path conflicts
  (`docs/notes-api.md`), and the moved `301` / deleted `410` responses;
- `/rss.xml`, `og:image` via `SiteHead`, `/sitemap*.xml`;
- the `/garden/*` and `/projects/[slug]` 301s, and the notes host and its
  canonicals;
- Studio and admin auth, same-origin mutation checks, `no-store` admin pages,
  middleware headers, and the `public/_headers` frame policy;
- content-version invalidation.

None of these files are edited, and Rubric's renderer and security work is not
reimplemented.

## 6. Tests and verification

- **The CI suite:**
  - `pnpm run verify`, which runs format:check, check, test and build;
  - `RUN_REDIS_INTEGRATION=1 pnpm exec vitest run
    tests/storage-integration.test.ts` against a local Redis 7;
  - `pnpm run test:browser`.
- **New unit tests:**
  - the prepaint whitelist (bogus, partial and denied storage);
  - the header's current state, and one notes link per page;
  - `SiteHead` default output unchanged;
  - `pickHomeProjects` unchanged.
- **Updated:** `tests/browser/projects.spec.ts` (gallery to column) and
  `tests/project-image.test.ts` if the CSS moves.
- **Playwright pass:**
  - `/`, `/projects` and `/about` at 1440, 390 and 320, in light and dark;
  - 200% text;
  - `emulateMedia({ reducedMotion: 'reduce' })`;
  - real keyboard: Tab to the icon, Enter, arrow keys, Escape returns focus;
  - storage denied;
  - no horizontal scroll;
  - CSP console clean.
- **Baseline diff:** every run is compared with the M0 baseline. Any change on
  notes, admin or Studio counts as a regression.

## 7. Local preview (only after an approved implementation)

- Command: `pnpm run dev -- --host 0.0.0.0 --port 4321`.
- URLs: http://localhost:4321 and http://<LAN-IP>:4321.
- Dev needs the reachable local Redis and the `127.0.0.1` bridge. Only the
  dev server binds to the LAN.

## Open decisions for the owner at the stop point

1. The base commit (section 0).
2. The About guestbook (live, omitted in the mock): keep it in the new
   shell, or drop it.
3. The Spotify/Lanyard widget, page previews and the loading bar on portfolio
   pages: keep or drop.
4. Removing RecentNotes from home.
5. The h1 → about link, which duplicates the nav.
6. The three gated admin edits in section 3.
