# oddava.me mockups v4: composition B, iterated

Static, self-contained mockups of the home and about pages. These are not
production pages, and nothing in the site's `src/` was changed. v3
(`../mockups-v3/`) is untouched.

- `index.html` links both pages and these notes.
- `home.html` and `about.html` are each built into one file: fonts, CSS and JS
  are inlined, and they work offline from `file://`.
- `src/` holds the sources. Run `node build.mjs` to rebuild the pages,
  `node qa.mjs <dir>` to write the QA probe variants, and `node contrast.mjs`
  for the contrast table.
- `COPY-SOURCES.md` records where every word came from: main commit
  `8f84eca42ed9237ef98d9e644970ae0bc21ad1ff`.
- `SOURCES.md` covers the vereis.com study and the other references.
- `TEST-RESULTS.md` has the probe output and the contrast table.

## What changed from v3 B

1. **The logo is plain.** The dd tie is gone. The wordmark is just `oddava` in
   DM Sans 600 at 19px, with normal glyphs and kerning, no ligature, bar or
   mascot.
2. **Copy is the site's own, word for word,** from main `8f84eca`:
   - the lowercase tagline;
   - the three About paragraphs;
   - the About title and meta;
   - the four checked-in default projects.

   There is no real name anywhere. Invented bio lines from older mocks are gone.
   The home notes section is omitted: the only notes link is "notes" in the nav,
   to notes.oddava.me.
3. **Light and dark themes,** plus a system setting that follows the OS.
4. **The six appearance preferences are back,** in an unobtrusive "appearance"
   control in the footer.
5. **Small personal touches** suited to someone who lists games and anime as
   interests (see below).

## Appearance preferences

Saved as JSON in `localStorage.appearance`. Applied before first paint by an
inline script that checks each value against an allow-list, then set as
attributes on `<html>`:

| attribute      | values                                    | default       | effect                                                                                       |
| -------------- | ----------------------------------------- | ------------- | -------------------------------------------------------------------------------------------- |
| `data-theme`   | system, light, dark                       | system        | Token set. System follows `prefers-color-scheme`.                                            |
| `data-ink`     | ai, sakura, matcha, fuji, sora            | ai (#245DCC)  | Accent and focus ring, each with its own light and dark value (contrast in TEST-RESULTS). No cream, coral or yellow. |
| `data-read`    | sans, serif                               | sans          | Prose only (`.prose`: tagline, project blurbs, about body). Serif is Lora. UI and headings stay DM Sans. |
| `data-size`    | standard, large                           | standard      | Root size 100% or 112.5%; every size is in rem, so all of it scales.                         |
| `data-density` | comfortable, compact                      | comfortable   | Vertical rhythm × 0.68 and line height 1.6 → 1.5.                                            |
| `data-motion`  | system, reduced                           | system        | Reduced turns off the panel animation, the press settle and the peek rise. The OS reduced-motion setting always wins. |

The control:

- **Toggle:** a native `<button>` with `aria-expanded` and `aria-controls`. Its
  dot shows the current ink.
- **Panel:** `role=group`, labelled by its heading. Each preference is a native
  radio `<fieldset>` with a `<legend>`, styled as segments with a visible focus
  ring. Changes apply instantly; there is no save button.
- **Closing:**
  - Escape closes the panel and returns focus to the toggle.
  - An outside pointerdown closes it and returns focus only if focus was inside.
  - Tabbing out of the panel closes it.
- **Placement:**
  - It opens upward when there is room above the toggle, otherwise downward
    (the short About page).
  - At ≤30em it becomes a fixed sheet along the bottom of the screen.
  - Its max height comes from `innerHeight`.
- **Reset** removes the key and restores the defaults.
- **Storage messages:** if storage is blocked, a `role=status` line says the
  settings won't persist. The controls still work for the visit.
- **Motion:** 170ms scale-and-fade in and 110ms out (WAAPI). It is cancelled if
  the panel is reopened mid-animation and skipped when motion is reduced.
- **Scope:** there are no notes-site settings.

## Personality: small, on purpose

The brief asked for cute and anime touches, without a mascot, cat, stars,
emoji bullets or a busy metaphor. Each touch is small, decorative only, and
hidden from assistive tech where it is a glyph:

- **A tilde under the name:** a 44px hand-drawn wave in the visitor's ink. It
  borrows the "~" voice from vereis.com, as a line rather than a character.
- **Wavy underlines:**
  - The current nav page gets a wavy underline (on About, "about" has it).
  - Text links turn wavy and take the ink colour on hover.
  - The resting underline stays straight, so links still read as links.
- **Kaomoji:**
  - `( ˘ω˘ )` sits quietly in the appearance panel header.
  - `(◕‿◕)` peeks in next to **AniShows**, the anime tracker, on hover or
    keyboard focus, with a 3px rise when motion is allowed.

  These are the only two, and nothing else on the page uses one.
- **Ink names:** ai, sakura, matcha, fuji, sora (indigo, cherry blossom, green
  tea, wisteria, sky). They are named like that rather than "blue/pink/green".
  Screen readers get both, for example "sakura (pink)".

Rejected:

- a character illustration (vereis's move, and it would read as copied);
- sparkles or stars;
- a loading cat;
- anime data such as a "currently watching" list: there is no such source data,
  and inventing it is not allowed.

## Second subtractive critique (on the final renders)

| Problem seen                                                                                | Fix                                                                                       |
| -------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| Panel captured mid-fade, looked translucent                                                  | Probe finishes animations before capture. The real open state is fully opaque.            |
| Ink choices wrapped onto three lines                                                         | Panel widened to 27rem, legend column 6rem                                                |
| Panel opened above the top of the page on the short About page, so it was unreachable        | Opens downward (`.below`) when there isn't room above                                     |
| `100dvh` rejected by the renderer, and the page min-height flex was unnecessary             | Removed. The panel max-height is set from `innerHeight` in JS.                            |
| Mobile: about 120px of dead space between the last project and the footer                   | Footer gap is 44px × density below 55em and stays 72px on desktop                         |
| Dark panel: swatches showed light-theme inks while the toggle dot showed the dark one       | Swatches use each ink's value for the current theme                                       |
| `( ˘ᵕ˘ )` rendered with a missing or tiny glyph in the system font                          | Replaced with `( ˘ω˘ )` (Greek ω is in every system font)                                 |
| About desktop: "for businesses." wraps alone at 1440                                        | Kept. `text-wrap: pretty` is avoiding a one-word "businesses." orphan; the copy is fixed. |

## Hard-ban check

| Ban                                                        | Status                                                                                              |
| ---------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| Cream or terracotta                                        | Pass. White/ink light theme, cool charcoal dark theme. Inks contain no cream, coral or yellow.      |
| Inter or Instrument Serif                                  | Pass. DM Sans throughout, with Lora only behind the serif preference.                               |
| Purple gradients, glass, card grids                        | Pass. No gradients or backdrop blur. Projects are a list, not cards.                                |
| Emoji bullets, stars, cat, mascot                          | Pass. Two aria-hidden kaomoji (explicitly permitted), no emoji.                                     |
| All-caps or mono microlabels, `§`, dotted leaders          | Pass. Lowercase labels in the UI face; no uppercase transforms or monospace.                        |
| An arrow on every link                                     | Pass. No arrows anywhere.                                                                           |
| Scroll choreography, loaders                               | Pass. No scroll-linked motion. Motion is the panel open/close, the 1px press settle and the peek.   |
| `transition: all`                                          | Pass. Every transition names its properties.                                                        |
| More than one notes link per page                          | Pass. Exactly one per page.                                                                         |
| Real name                                                  | Pass. "oddava" only.                                                                                |

## Screenshots

All captures are **full-page at auto height**: the frame grows to fit the
document. They are not cropped to a device viewport, so a 390 capture is
"390 wide, whole page", not a 390 × 844 phone screen.

Core (`screenshots/`):

| file                    | size        |
| ----------------------- | ----------- |
| `home-1440-light.png`   | 1440 × 754  |
| `home-1440-dark.png`    | 1440 × 754  |
| `home-390-light.png`    | 390 × 983   |
| `home-390-dark.png`     | 390 × 983   |
| `about-1440-light.png`  | 1440 × 556  |
| `about-1440-dark.png`   | 1440 × 556  |
| `about-390-light.png`   | 390 × 616   |
| `about-390-dark.png`    | 390 × 616   |

Settings open (`screenshots/`):

| file                            | size        | note                                                   |
| ------------------------------- | ----------- | ------------------------------------------------------ |
| `settings-open-1440-light.png`  | 1440 × 754  | opens upward from the footer toggle                    |
| `settings-open-1440-dark.png`   | 1440 × 754  |                                                        |
| `settings-open-390-light.png`   | 390 × 983   | fixed sheet. Position is relative to the auto-height frame, not a phone screen |
| `settings-open-390-dark.png`    | 390 × 983   | same                                                   |

QA (`screenshots/qa/`):

- `reflow-320-home-light.png`;
- `combo-home-1440-light-fuji-serif-large-compact-reduced.png`;
- `combo-about-390-dark-matcha-serif-large.png`;
- `denied-storage-about-1440-open-below.png`: the panel opening downward, with
  the storage status shown;
- `anishows-peek-focus-1440-dark.png`.

`reference/vereis-reference.png` is the vereis.com study render (see
SOURCES.md).

## Limitations

- **Projects:** the list is production's checked-in defaults. The live list is
  a Redis-backed server island and may differ. Admin and Redis were not
  touched.
- **Out of scope, omitted rather than faked:**
  - the guestbook (needs Redis, auth and signing);
  - now-playing;
  - the home carousel controls;
  - the cats.
- **Testing gaps:** there was no real Tab traversal or pointer automation (the
  preview tool's key and click input didn't work), no OS reduced-motion
  emulation and no screen-reader pass. See TEST-RESULTS.md.
- **The CSP / inline-script story is not production-shaped.** The mock inlines
  its scripts and has a few `style="--sl…"` attributes on swatches.
  Production's hashed CSP would want these as classes.
- **Not owner-approved.** This is a review iteration.
