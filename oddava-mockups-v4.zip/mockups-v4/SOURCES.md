# Sources and references

## vereis.com (inspiration, not copied)

Studied on 2026-11-11 in two ways:

- Read as text with WebFetch.
- Rendered in a sandboxed preview frame. That render is saved as
  `reference/vereis-reference.png` (1280 × 1416, full page, home only). A
  direct browser-tab screenshot timed out, so the frame render is the visual
  record.

Nothing was signed in to and no private or session data was used.

### What was observed

- A warm pastel canvas (cream with pink tints) and rounded, hand-lettered
  display type. The greeting runs "Ahoy~!! I'm vereis~!!", with tildes as
  part of the voice.
- A playful self-correction in the intro: a job title struck through and
  replaced with "Problem Solver :)".
- A large anime character illustration and layered cloud shapes in the hero.
- Line-drawn doodle icons in the nav and on each post tile.
- A pink hand-drawn underline under the current nav item.
- Pastel icon tiles per post, rounded pill buttons, and a filters sidebar on
  the post list.
- Candid, jokey post summaries (for example "Recursion is easy, but I'm a
  baka.").
- A footer credit naming the stack it was hand-made with.
- WebFetch found no dark mode or appearance settings, and none was visible in
  the render.

### What v4 borrows: principles only

| vereis mechanism                         | v4 adaptation                                                                                                     |
| ---------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| Hand-drawn mark under the current nav item | The current page's nav link gets a small CSS `wavy` underline in the visitor's ink (`.nav a[aria-current]`). No drawn asset. |
| Tildes as voice                          | A small tilde stroke under the home h1 (inline SVG, ink colour). Text links turn into a wavy underline on fine-pointer hover. |
| Small playful glyphs, not a mascot       | A kaomoji `( ˘ω˘ )` in the appearance panel header. `(◕‿◕)` peeks in next to AniShows on hover or keyboard focus. Both are `aria-hidden`. |
| Personality lives in details, not chrome | The layout stays the quiet two-column B. The personality is about four small touches.                         |

### What v4 does not take

- vereis's palette, cream/pink canvas, display or hand-lettered fonts;
- the character art, clouds, doodle icon set or post tiles;
- the pill buttons, sidebar or layout;
- any copy.

v4 keeps the original white/ink/blue system (DM Sans, `#245DCC` default ink)
and adds a dark theme of its own. Nothing here claims or implies how vereis.com
was made.

## Other references

- **v3 composition B** (`../mockups-v3/`, unchanged): the starting layout. It
  provides the name and tagline on the left with the work list on the right at
  desktop, stacked on mobile, plus the press settle and the token values. The
  dd-tie wordmark from v3 is removed outright.
- **The previous version's customize options**, as listed in the brief: theme,
  ink, reading font, text size, density, motion. Only the set of six
  preferences was carried over. No earlier CSS or markup was reused, and the
  vellum/lamplight theme names are replaced by system/light/dark.
- **Fonts:**
  - DM Sans variable (`fonts/DMSans-var.ttf`), from google/fonts `ofl/dmsans`,
    copied from v3, under the SIL OFL 1.1 (`fonts/DMSans-OFL.txt`).
  - Lora variable (`fonts/Lora-variable.ttf`), from google/fonts `ofl/lora` via
    the repo's `design-directions/fonts`, unmodified (sha256
    `822a6621ccbe8d97d20ac88c1c41f5615c9c2c202eaa75f272cd452aac6475a7`), under
    the SIL OFL 1.1 (`fonts/Lora-OFL.txt`). It is used only for the
    "reading font: serif" preference.
- **WCAG 2.2** contrast (1.4.3, 1.4.11), reflow (1.4.10), focus visible
  (2.4.7) and target size (2.5.8) for the QA thresholds.
