# Copy sources

Every visible word in `home.html` and `about.html` comes from the `main` branch
at commit **`8f84eca42ed9237ef98d9e644970ae0bc21ad1ff`**, read with
`git show <commit>:<path>` (read-only: no checkout, branch change or fetch).
No copy was taken from the Rubric branch or the old rewritten content inventory.
The mock adds no copy except UI labels for the new appearance control.

The mockups contain no real name. The only name used anywhere (title, meta,
headings, accessible labels) is **oddava**, as in the source.

## Files read

| Path                                 | Blob at 8f84eca                            | Used for                                             |
| ------------------------------------ | ------------------------------------------ | ---------------------------------------------------- |
| `src/pages/index.astro`              | `f51cddfd3da615c983957a1fc64f0636f33c4cfa` | home h1, tagline, contacts line                      |
| `src/pages/about.astro`              | `428102d6ac5c806fc0b3dc4b5fe3629486a75449` | about title, meta description, h1, three paragraphs  |
| `src/lib/server/projects/defaults.ts`| `4fd97ac423d6f4319d2b095109c4511e1c5bd6a7` | project names, descriptions, links, order            |
| `src/lib/home.ts`                    | `54a99f3e031ec32e69d5c24719cb43390cb94488` | `HOME_PROJECT_LIMIT = 3` (see deviations)            |
| `src/data/links.json`                | `cabcaaef42f993f4a3e5c73695128418baed3ea3` | github, x, email hrefs                               |
| `src/lib/site.ts`                    | `c9954c05bcbafaa378f89cc6556730f7195364d2` | `SITE_NAME`, `SITE_TITLE`, home meta description     |
| `src/components/SiteHead.astro`      | `a52c8e38b71841eb083c689aed694055a9f908b1` | page title pattern                                   |
| `src/components/SiteNav.astro`       | `c2da80f2a097406ad91adb0909f083f732aa9db8` | nav order (about, projects, notes), wordmark text    |

## Verbatim excerpts

**Home h1:** `oddava`

**Home tagline** (lowercase as in source, `&nbsp;` kept):

> i write software, interrogate SI (silly intellect), and make tools for small&nbsp;annoyances.

**Contacts line** (`aria-label="contact and feeds"`): `github`, `x`, `email`,
`rss`. These are the lowercased `links.json` titles, the same as the source
renders them. External links open in a new tab with the source's sr-only text
"(opens in new tab)".

**Home title:** `Oddava` (`SITE_TITLE`, because the page title equals
`SITE_NAME`). **Home meta description** (`SITE_DESCRIPTION`):

> oddava is a backend developer. Notes on the software I build, the books I read, and what I learn along the way.

**About title:** `About | oddava` (SiteHead pattern `${title} | ${SITE_NAME}`).
**About meta description:**

> Oddava is a software engineer based in Uzbekistan, building web applications and working on Ishbay.

**About h1:** `about`

**About paragraphs:**

> i'm a software engineer based in uzbekistan. i build web applications, currently working on [Ishbay](https://ishbay.com), a payroll management platform for businesses.
>
> i'm interested in backend engineering, system design, self-hosting, and developer tools.
>
> outside of coding, i enjoy games, anime, and going on long walks.

**Projects** (`DEFAULT_PROJECTS`, in source order, descriptions word for word):

1. **Ishbay** (https://ishbay.com): payroll management for businesses. my day job.
2. **oddava.me** (https://github.com/oddava/oddava.me): this site. notes live in redis and go public the moment studio autosaves, no deploy in between.
3. **oddava notes** (https://github.com/oddava/obsidian-oddava-notes): an obsidian plugin that publishes notes from my vault to this site and pulls edits back, phone included.
4. **AniShows** (https://github.com/oddava/aniShows): an anime tracker with reviews, forums, and a catalog synced from AniList.

"my day job." is in the source's Ishbay description, so it stays. No other
"day job", junior, Node or Tashkent wording from older mocks appears.

## Deviations and limits

- **Projects are a dynamic server island in production.** `/projects` and the
  home strip render from the `projects:list` Redis hash, edited in `/admin`. The
  mock uses the checked-in `DEFAULT_PROJECTS`, which is what production serves
  only before the first admin save. **The live list may differ.** Admin and
  Redis were not read or touched.
- **All four projects are shown.** Production's home strip shows
  `HOME_PROJECT_LIMIT = 3` plus an "N more" tile. With four short entries a
  "1 more" tile would cost more than it saves, so the mock lists all four. The
  "projects" nav item points at this list (`#projects`), not a separate page.
- **Flagged for the owner:** the oddava.me and oddava notes descriptions still
  say notes live on "this site". They predate the notes.oddava.me split. They
  are kept word for word as instructed. The owner may want to edit them in
  `/admin`.
- **rss** links to `https://oddava.me/rss.xml` (absolute) because the mock is a
  static file. The source uses the relative `/rss.xml`.
- **The notes link** is `https://notes.oddava.me`, the separate notes site. Each
  page has exactly one notes link (in the nav). The old home's notes section is
  omitted.
- **Omitted rather than faked:**
  - the about-page guestbook (a `client:idle` island backed by Redis, plus
    auth and signing);
  - its `noscript` mailto line;
  - the Spotify/Lanyard now-playing islands;
  - the home project carousel's prev/next controls;
  - the awake/napping cat canvases and the "pet the cat" button (excluded by
    the no-cat rule).
- **No invented content:** there is no now-watching, status, anime list, stack,
  experience or location claim beyond the source copy above.
- **New UI copy written for the mock** (not from the source):
  - the appearance panel: "appearance", legends and option names, "reset";
  - the status messages: "this browser isn't keeping settings, so they'll reset
    on reload.", "back to the defaults.", "back to the defaults for this visit.";
  - the sr-only colour names;
  - "skip to content".
