// Appearance panel: six preferences, saved as JSON in localStorage.appearance.
(function () {
  var KEY = 'appearance';
  var DEFAULTS = {
    theme: 'system',
    ink: 'ai',
    read: 'sans',
    size: 'standard',
    density: 'comfortable',
    motion: 'system',
  };
  var root = document.documentElement;
  var toggle = document.getElementById('appearance-toggle');
  var panel = document.getElementById('appearance-panel');
  var form = document.getElementById('appearance-form');
  var resetBtn = document.getElementById('appearance-reset');
  var status = document.getElementById('appearance-status');
  if (!toggle || !panel || !form) return;

  var canSave = true;

  function current() {
    var out = {};
    for (var k in DEFAULTS) out[k] = root.getAttribute('data-' + k) || DEFAULTS[k];
    return out;
  }

  function save(prefs) {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(prefs));
      canSave = true;
    } catch (e) {
      canSave = false;
    }
    status.textContent = canSave
      ? ''
      : "this browser isn't keeping settings, so they'll reset on reload.";
  }

  function syncForm(prefs) {
    for (var k in prefs) {
      var input = form.querySelector(
        'input[name="' + k + '"][value="' + prefs[k] + '"]',
      );
      if (input) input.checked = true;
    }
  }

  function apply(prefs) {
    for (var k in prefs) root.setAttribute('data-' + k, prefs[k]);
  }

  syncForm(current());

  // Storage can be blocked (private modes, site-data settings). The controls
  // still work for this page; say so instead of failing silently.
  try {
    window.localStorage.getItem(KEY);
  } catch (e) {
    canSave = false;
    status.textContent =
      "this browser isn't keeping settings, so they'll reset on reload.";
  }

  form.addEventListener('change', function () {
    var prefs = current();
    var data = new FormData(form);
    for (var k in DEFAULTS) prefs[k] = data.get(k) || prefs[k];
    apply(prefs);
    save(prefs);
  });

  resetBtn.addEventListener('click', function () {
    apply(DEFAULTS);
    syncForm(DEFAULTS);
    try {
      window.localStorage.removeItem(KEY);
      canSave = true;
      status.textContent = 'back to the defaults.';
    } catch (e) {
      status.textContent = 'back to the defaults for this visit.';
    }
  });

  // Motion: a short scale-and-fade from the trigger, only when motion is on.
  function motionOn() {
    return (
      root.getAttribute('data-motion') !== 'reduced' &&
      !window.matchMedia('(prefers-reduced-motion: reduce)').matches
    );
  }

  var running = null;

  function open() {
    if (running) running.cancel();
    panel.hidden = false;
    // Keep the whole panel reachable on short screens.
    panel.style.maxHeight = Math.max(240, window.innerHeight - 24) + 'px';
    toggle.setAttribute('aria-expanded', 'true');
    // Open upward when there is room above the trigger, otherwise downward.
    panel.classList.remove('below');
    var above = toggle.getBoundingClientRect().top + window.scrollY;
    if (above < panel.offsetHeight + 16) panel.classList.add('below');
    if (motionOn() && panel.animate) {
      running = panel.animate(
        [
          { opacity: 0, transform: 'scale(0.96) translateY(4px)' },
          { opacity: 1, transform: 'none' },
        ],
        { duration: 170, easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)' },
      );
    }
    var checked = form.querySelector('input:checked');
    if (checked) checked.focus({ preventScroll: true });
  }

  function close(restoreFocus) {
    if (panel.hidden) return;
    if (running) running.cancel();
    toggle.setAttribute('aria-expanded', 'false');
    var finish = function () {
      panel.hidden = true;
      running = null;
    };
    if (motionOn() && panel.animate) {
      running = panel.animate(
        [
          { opacity: 1, transform: 'none' },
          { opacity: 0, transform: 'scale(0.98)' },
        ],
        { duration: 110, easing: 'ease-in' },
      );
      running.onfinish = finish;
    } else {
      finish();
    }
    if (restoreFocus) toggle.focus({ preventScroll: true });
  }

  toggle.addEventListener('click', function () {
    if (toggle.getAttribute('aria-expanded') === 'true') close(false);
    else open();
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
      event.preventDefault();
      close(true);
    }
  });

  document.addEventListener('pointerdown', function (event) {
    if (toggle.getAttribute('aria-expanded') !== 'true') return;
    if (panel.contains(event.target) || toggle.contains(event.target)) return;
    var hadFocus = panel.contains(document.activeElement);
    close(hadFocus);
  });

  // Tabbing past the panel closes it without moving focus back.
  panel.addEventListener('focusout', function (event) {
    var next = event.relatedTarget;
    if (next && !panel.contains(next) && next !== toggle) close(false);
  });

  // Lets :active fire on touch so the press response matches pointer use.
  document.addEventListener('touchstart', function () {}, { passive: true });
})();
